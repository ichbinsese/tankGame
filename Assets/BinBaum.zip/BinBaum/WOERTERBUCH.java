
/**
 * Englisch-deutsches Woerterbuch als geordneter Binaerbaum (ohne Composite Pattern) implementiert.
 * 
 */
public class WOERTERBUCH
{
    /**
     * Implementierung des Woerterbuchs als geordneter Binaerbaum 
     */
    private BINBAUM woerterbuch;

    /**
     * Konstruktor fuer Objekte der Klasse WOERTERBUCH, erzeugt ein englisches Woerterbuch 
     * mit 7 Eintraegen.
     */
    /*public WOERTERBUCH()
    {
        woerterbuch = new BINBAUM();
        einfuegen("clip","Klammer, abschneiden, anstecken" );
        einfuegen("car","Auto, Fahrzeug, Waggon" );
        einfuegen("cat","Katze" );
        einfuegen("care","Fuersorge, Sorgfalt" );
        einfuegen("cave","Hoehle, aushoehlen, einbrechen" );
        einfuegen("crab","Krabbe, Krebs, Griesgram" );
        einfuegen("coin","Muenze, auspraegen, erfinden" );
    
    }*/

     /**
     * einfuegen() erzeugt ein Objekt der Klasse WOERTERBUCHEINTRAG mit den Eingabewerten und
     * fuegt diesen Woerterbucheintrag sortiert in den Baum woerterbuch ein. Es wird verhindert, 
     * dass ein englisches Wort mehrfach im Woerterbuch abgespeichert werden kann.
     * @param wort      englisches Wort
     * @param bedeutung die deutsche(n) Bedeutung(en).
     */
    /*public void einfuegen(String wort, String bedeutung) {
        WOERTERBUCHEINTRAG neuerWoerterbucheintrag;
        neuerWoerterbucheintrag = new WOERTERBUCHEINTRAG(wort, bedeutung);
        woerterbuch.einfuegen(neuerWoerterbucheintrag);
    }*/
    
     /**
     * Sucht ein englisches Wort im Woerterbuch
     * @param vergleichswert gesuchter Schluessel
     * @return gesuchter Woerterbucheintrag
     */
    /*public DATENELEMENT suchen(String gesuchtesWort)
    {
         return woerterbuch.suchen(gesuchtesWort);
    }*/
    
    /**
    * Die Methode bedeutungSetzen ermoeglicht es, bei einem englischen Wort
    * die deutsche Bedeutung zu veraendern.
    * @param gesuchtesWort  englisches Wort, dessen Bedeutung veraendert werden soll
    * @param bedeutungNeu   neue Bedeutung
    */
    /*public void bedeutungSetzen(String gesuchtesWort, String bedeutungNeu) {
        WOERTERBUCHEINTRAG woerterbucheintrag;
        woerterbucheintrag = (WOERTERBUCHEINTRAG) suchen(gesuchtesWort);
        if (woerterbucheintrag == null) {
            System.out.println("Eintrag existiert nicht!");
        } else {
            woerterbucheintrag.bedeutungSetzen(bedeutungNeu);
        }
    }*/
}
