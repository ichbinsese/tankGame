
public class KNOTEN extends BAUMELEMENT {

    // Referenz auf das Datenelement
    private DATENELEMENT daten;
      

    /**
     * Setter und Getter fuer die Daten
     */
    public void datenSetzen(DATENELEMENT datenNeu) 
    {
        daten = datenNeu;
    }

    public DATENELEMENT datenGeben() 
    {
        return daten;
    }

}