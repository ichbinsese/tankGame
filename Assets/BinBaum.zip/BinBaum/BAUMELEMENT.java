/**
 * Abstrakte Klasse BAUMELEMENT zur Realisierung einer Baumstruktur mit Hilfe des Entwurfsmusters
 * Kompositum: Die Klasse legt ausschließlich die Schnittstelle für die Klassen
 * KNOTEN und ABSCHLUSS in Form von Methoden fest.
 */

abstract class BAUMELEMENT {
}
