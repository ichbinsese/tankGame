//import java.lang.String.*;

/**
 * Die Klasse WOERTERBUCHEINTRAG dient zur Speicherung von
 * Woerterbucheintraegen fuer ein Englisch-Deutsches 
 * Woerterbuch. Dabei kann jedem englischen Wort mehrere 
 * deutsche Bedeutungen zugeordnet werden, wobei alle Bedeutungen in 
 * einer einzigen Zeichenkette Bedeutung gespeichert werden.
 */

public class WOERTERBUCHEINTRAG implements DATENELEMENT {
    /**
     * Englisches Wort; 
     * Schluessel dieses Datenelements
     */    
    private String wort; 
    
    /**
     * Deutsche Bedeutung; 
     * mehrere Bedeutungen werden als eine Zeichenkette zusammengefasst
     */  
    private String bedeutung;    

    /**
     * Konstruktor fuer Objekte der Klasse WOERTERBUCHEINTRAG
     * @param wortNeu das englische Wort.
     * @param bedeutungNeu die deutsche(n) Bedeutung(en).
     */
    public WOERTERBUCHEINTRAG(String wortNeu, String bedeutungNeu) {
        wort = wortNeu;
        bedeutung = bedeutungNeu;
    }

    /**
     * Gibt Information ueber das Datenelement zu Kontrollzwecken
     * auf das Terminalfenster aus.
     */
    public void infoAusgeben() {
        System.out.println(wort + ": " + bedeutung);
    }

     /**
     * Vergleicht zwei Datenelemente bezueglich der Ordnungsrelation.
     * @param vergleichselement Datenelement mit dem das Objekt verglichen wird.
     * @return true, wenn das aktuelle Element einen kleineren Schluessel 
     * hat, als das angegebene Vergleichselement.
     */
    public boolean istKleinerAls(DATENELEMENT dvergleich) {
       // Ueberpruefung, ob der Eingabewert vom Typ WOERTERBUCHEINTRAG (WBE) ist
       // Andernfalls Casten / Konvertierung
       WOERTERBUCHEINTRAG vergleichsWBE;
       vergleichsWBE = (WOERTERBUCHEINTRAG) dvergleich;
       
       if(wort.compareTo(vergleichsWBE.wortGeben()) < 0) {
           return true;
       } else {
           return false;
       }       
    }
    
     /**
     * Vergleicht zwei Datenelemente auf Gleichheit.
     * @param dvergleich Datenelement mit dem das Objekt verglichen wird.
     * @return true, wenn die beiden Datenelemente gleichen Schluessel haben.
     */
    public boolean istGleich(DATENELEMENT dvergleich)
    {
       // Ueberpruefung, ob der Eingabewert vom Typ WOERTERBUCHEINTRAG (WBE) ist
       // Andernfalls Casten / Konvertierung
       WOERTERBUCHEINTRAG vergleichsWBE;
       vergleichsWBE = (WOERTERBUCHEINTRAG) dvergleich;
       
       if(wort.equals(vergleichsWBE.wortGeben())) {
           return true;
       } else {
           return false;
       }       
    }
  
     /**
     * Vergleicht zwei Datenelemente bezueglich der Ordnungsrelation.
     * @param vergleichselement Datenelement mit dem das Objekt verglichen wird.
     * @return true, wenn das aktuelle Element einen groe&szlig;eren Schluessel 
     * hat, als das angegebene Vergleichselement.
     */
    public boolean istGroesserAls(DATENELEMENT dvergleich)
    {
       // Ueberpruefung, ob der Eingabewert vom Typ WOERTERBUCHEINTRAG (WBE) ist
       // Andernfalls Casten / Konvertierung
       WOERTERBUCHEINTRAG vergleichsWBE;
       vergleichsWBE = (WOERTERBUCHEINTRAG) dvergleich;
       
       if(wort.compareTo(vergleichsWBE.wortGeben()) > 0) {
           return true;
       } else {
           return false;
       }       
    }
        
     /**
     * Vergleicht zwei Schluessel, die als Zeichenketten vorliegen, auf Gleichheit.
     * @param vergleichsSchluessel Schluessel  mit dem der Schluessel des Objekt verglichen wird.
     * @return true, wenn die beiden Schluessel gleich sind.
     */
    public boolean schluesselIstGleich (String vergleichsSchluessel)
    {
        return (wort.equals(vergleichsSchluessel));
    }
    
     /**
     * Vergleicht zwei Schluessel, die als Zeichenketten vorliegen, bezueglich der Ordnungsrelation.
     * @param vergleichsSchluessel Schluessel  mit dem der Schluessel des Objekt verglichen wird.
     * @return true, wenn das aktuelle Element einen groe&szlig;eren Schluessel 
     * hat, als das angegebene Vergleichselement.
     */
    public boolean schluesselIstGroesserAls(String vergleichsSchluessel)
    {
       if(wort.compareTo(vergleichsSchluessel) > 0) {
           return true;
       } else {
           return false;
       }     
    }
    
    /**
     * Vergleicht zwei Schluessel, die als Zeichenketten vorliegen, bezueglich der Ordnungsrelation.
     * @param vergleichsSchluessel Schluessel  mit dem der Schluessel des Objekt verglichen wird.
     * @return true, wenn das aktuelle Element einen kleineren Schluessel 
     * hat, als das angegebene Vergleichselement.
     */
    public boolean schluesselIstKleinerAls(String vergleichsSchluessel){
       if(wort.compareTo(vergleichsSchluessel) < 0){
           return true;
       } else {
           return false;
       }     
    }

    /**
     * Gibt den Schluessel des Datenelements als String aus, auch wenn der Datentyp vom 
     * String abweicht. Diese Methode wird beim Entfernen eines Knotens benoetigt.
     * @return Schluessel als String.
     */
    public String schluesselAlsStringGeben(){
        return wort;
    }
    
  
    /**
     * Getter fuer Attribut wort
     * 
     * @return das englische Wort
     */
    public String wortGeben() {
        return wort;
    }
    
    /**
     * Getter fuer Attribut bedeutung
     * 
     * @return   bedeutung   die deutsche(n) Bedeutung(en) als eine Zeichenkette
     */
    public String bedeutungGeben() {
        return bedeutung;
    }
    
    /**
     * Setter fuer Attribut bedeutung
     * 
     * @param   bedeutungNeu neue Bedeutung fuer das englische Wort
     */
    public void bedeutungSetzen(String bedeutungNeu) {
        bedeutung = bedeutungNeu;
    }
    
}
