
/**
 * Das Interface DATENELEMENT dient als Schnittstelle zum Speichern von
 * Daten in rekursiven Datenstrukturen. Jedes Datenelement hat ein
 * Schluesselattribut, auf das eine Ordnungsrelation festgelegt ist
 * Es werden vergleichende Methoden wie istGleich und istKleiner
 * aehnlich wie im Java Interface Comperable festgelegt, die 
 * fuer Such- und sortierte Einfuegeoperationen in die Datenstruktur 
 * notwendig sind.
 * 
 * @author A. Eckstein 
 * @version Jan 2017
 */

public interface DATENELEMENT
{
    /**
     * Gibt Information ueber das Datenelement zu Kontrollzwecken
     * aus.
     */
    void infoAusgeben();

    /**
     * Vergleicht zwei Datenelemente bezueglich der Ordnungsrelation.
     * @param dvergleich Datenelement mit dem das Objekt verglichen wird.
     * @return true, wenn das aktuelle Element einen kleineren Schluessel 
     * hat, als das eingegebene Datenelement dvergleich.
     */
    boolean istKleinerAls(DATENELEMENT dvergleich);
    
    /**
     * Vergleicht zwei Datenelemente auf Gleichheit.
     * @param dvergleich Datenelement mit dem das Objekt verglichen wird.
     * @return true, wenn die beiden Datenelemente gleichen Schluessel haben.
     */
    boolean istGleich(DATENELEMENT dvergleich);
    
    /**
     * Vergleicht zwei Datenelemente bezueglich der Ordnungsrelation.
     * @param dvergleich Datenelement mit dem das Objekt verglichen wird.
     * @return true, wenn das aktuelle Element einen gr&ouml;&szlig;eren Schluessel 
     * hat, als das eingegebene Datenelement dvergleich.
     */
    boolean istGroesserAls(DATENELEMENT dvergleich);
     
    
    /**
     * Vergleicht zwei Schluessel, die als Zeichenketten vorliegen, auf Gleichheit.
     * @param vergleichsSchluessel Schluessel  mit dem der Schluessel des Objekt verglichen wird.
     * @return true, wenn die beiden Schluessel gleich sind.
     */
    boolean schluesselIstGleich(String vergleichsSchluessel);
    
    /**
     * Vergleicht zwei Schluessel, die als Zeichenketten vorliegen, bezueglich der Ordnungsrelation.
     * @param vergleichsSchluessel Schluessel  mit dem der Schluessel des Objekt verglichen wird.
     * @return true, wenn das aktuelle Element einen gr&ouml;&szlig;eren Schluessel 
     * hat, als das angegebene Vergleichselement.
     */
    boolean schluesselIstGroesserAls(String vergleichsSchluessel);

    /**
     * Vergleicht zwei Schluessel, die als Zeichenketten vorliegen, bezueglich der Ordnungsrelation.
     * @param vergleichsSchluessel Schluessel  mit dem der Schluessel des Objekt verglichen wird.
     * @return true, wenn das aktuelle Element einen kleineren Schluessel 
     * hat, als das angegebene Vergleichselement.
     */
    public boolean schluesselIstKleinerAls(String vergleichsSchluessel);
    
    /**
     * Gibt den Wert Schluessel als String zurueck. Diese allgemeine Methode ist n&ouml;tig, da in den
     * von DATENELEMENT abgeleiteten Klassen nicht ein allgemeines Attribut schluessel vom Typ String
     * existiert, sondern Name und Datentyp Schluessels frei gew&auml;hlt werden kann.
     * Diese Methode wird beim Entfernen eines Knotens ben&ouml;tigt.
     * @return Schluessel als String 
     */
    public String schluesselAlsStringGeben();
}

