/**
 * Die Klasse BINBAUM ist die Grundstruktur eines geordneten Binaerbaums. 
 * Die Methoden die ein Objekt dieser Klasse anbietet, leiten den Aufruf an den
 * Wurzelknoten weiter, wenn der Baum nicht leer ist.
 * (Implementierung ohne Composite Pattern)
 */
public class BINBAUM {
   
}
