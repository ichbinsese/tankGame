/**
 * Klasse ABSCHLUSS als Bestandteil eines geordneten Binaerbaums.
 * (Implementierung mit Composite Pattern)
 * 
 */
public class ABSCHLUSS extends BAUMELEMENT {

}
